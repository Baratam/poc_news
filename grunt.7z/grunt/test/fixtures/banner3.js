
// This is
// A sample
// Banner

// But this is not

/* And neither
 * is this
 */
