angular.module('capapp')

.service('capAppService', function(){

	this.user = {
			firstName: "Brajadulal",
			middleName: "",
			lastName: "Patnaik",
			tittle:"Sr.Manager",
			department: "FS GBU",
			country: "INDIA",
			place: "Hyderabad",
			account: "ING",
			bPhone: "4028686",
			mobile:"+91 9666112887",
			};
});

