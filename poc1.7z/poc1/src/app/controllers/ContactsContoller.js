angular.module('capapp')

.controller("contactsContoller", function ($log, $scope) {

	$log.debug("init contacts Contoller");
	$scope.rememberMe = false;

   });
