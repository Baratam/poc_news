angular.module('capapp')

.service('capAppService', function(){

	this.user = {
			welcomeNote: "Welcome To Capgemini",
			firstName: "",
			middleName: "",
			lastName: "",
			tittle:"",
			department: "",
			country: "India",
			place: "Hyderabad",
			account: "",
			bPhone: "",
			mobile:"",
			};
});

