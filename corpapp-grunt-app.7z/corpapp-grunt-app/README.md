corpapp-grunt-app
=================

Grunt module to build modules together into one app.

tasks
-----

- grunt-contrib-concat
- grunt-contrib-copy
- grunt-contrib-connect
- grunt-contrib-watch
- grunt-contrib-jshint
- grunt-contrib-uglify
- grunt-contrib-cssmin
- grunt-concat-css
- grunt-html-build
- grunt-bower-task