'use strict';
var fs = require('fs');
module.exports = function (grunt) {
	require("corpapp-grunt")(grunt, __dirname);



	grunt.registerTask("copy:app", function(){
		var bower = grunt.file.readJSON("bower.json");

		Object.keys(bower.dependencies).forEach(function(key) {

			console.log("Copy: " + key);
			var cwd = 'bower_components/' + key;

			//Copy views
			grunt.file.expand({cwd : cwd}, 'dist/views/**').forEach(function(path) {
				console.log("Path", path);
				if(grunt.file.isFile(cwd + "/" + path)){
					grunt.file.copy(cwd + "/" + path, path);
				}
			});

			//Copy images
			grunt.file.expand({cwd : cwd}, 'dist/images/**').forEach(function(path) {
				console.log("Path", path);
				if(grunt.file.isFile(cwd + "/" + path)){
					grunt.file.copy(cwd + "/" + path, path);
				}
			});

			//Copy images
			grunt.file.expand({cwd : cwd}, 'dist/fonts/**').forEach(function(path) {
				console.log("Path", path);
				if(grunt.file.isFile(cwd + "/" + path)){
					grunt.file.copy(cwd + "/" + path, path);
				}
			});

		});
	})
};