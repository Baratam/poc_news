module.exports = {
	hub: {
		app: {
			src: [
				'../*/gruntfile.js'
			],
			tasks: ['watch']
		}
	}
};