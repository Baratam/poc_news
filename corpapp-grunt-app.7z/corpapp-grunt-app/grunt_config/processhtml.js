module.exports = {
    processhtml: {
		dist: {
			files: {
				'dist/index.html': [
					'src/index.html'
				]
			}
		}
    }
};