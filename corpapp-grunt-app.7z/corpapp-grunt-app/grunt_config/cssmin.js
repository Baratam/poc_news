module.exports = {
	cssmin: {
		app: {
			files: {
    			'dist/app.min.css': ['dist/app.css']
    		}
		}
	}
};
