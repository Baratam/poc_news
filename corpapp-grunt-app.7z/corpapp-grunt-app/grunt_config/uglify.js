module.exports = {
	uglify: {
		app: {
			files: {
				'dist/app.min.js': 'dist/app.js'
			}
		}
	}
};