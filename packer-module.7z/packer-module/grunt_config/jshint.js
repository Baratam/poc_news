module.exports = {
	jshint: {
		all: [
			'gruntfile.js',
			'src/**/*.js', 
			'test/**/*.js'
		]
	}
};