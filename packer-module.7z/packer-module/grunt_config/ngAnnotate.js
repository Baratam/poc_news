module.exports = {
	ngAnnotate: {
        options: {
            singleQuotes: true,
        },
        module: {
	        files: {
	            'dist/app/module.js': ['dist/app/module.js'],
	        }
	    }
	}
};