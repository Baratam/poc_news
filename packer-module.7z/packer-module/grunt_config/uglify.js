module.exports = {
	uglify: {
		module: {
			files: {
				'dist/app/module.min.js': 'dist/app/module.js'
			}
		}
	}
};