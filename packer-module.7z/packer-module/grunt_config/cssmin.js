module.exports = {
	cssmin: {
		module: {
			files: {
    			'dist/css/module.min.css': ['dist/css/module.css']
    		}
		}
	}
};
