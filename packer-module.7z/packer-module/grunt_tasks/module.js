module.exports = {
	'module' : [
		'jshint:all', 
		'concat:module',
		'ngAnnotate:module',
		'uglify:module',
		'cssmin:module',
		'copy:module'
	],

	'module:run' : [
		'module',
		'connect:module',
		'watch:module'
	]
};