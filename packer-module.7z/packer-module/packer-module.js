'use strict';
module.exports = function (grunt) {
	require("packer-core")(grunt, __dirname);
};