corpapp-grunt-module
====================

Grunt module to build modules for the corpapp framwork. This module contains all the logic for concatenate, jslint, uglify, minify and run a module.

tasks
-----

- grunt-contrib-concat
- grunt-contrib-copy
- grunt-contrib-connect
- grunt-contrib-watch
- grunt-contrib-jshint
- grunt-contrib-uglify
- grunt-contrib-cssmin
- grunt-concat-css
- grunt-html-build
- grunt-bower-task