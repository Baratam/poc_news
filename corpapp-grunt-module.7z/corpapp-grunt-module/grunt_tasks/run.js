module.exports = {
	run : [
		'build',
		'connect:module',
		'watch:module'
	]
};