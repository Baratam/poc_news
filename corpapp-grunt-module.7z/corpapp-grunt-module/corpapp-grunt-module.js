'use strict';
module.exports = function (grunt) {
	require("corpapp-grunt")(grunt, __dirname);
};