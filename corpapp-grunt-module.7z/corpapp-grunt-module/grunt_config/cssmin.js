module.exports = {
	cssmin: {
		module: {
			files: {
    			'dist/module.min.css': ['dist/module.css']
    		}
		}
	}
};
