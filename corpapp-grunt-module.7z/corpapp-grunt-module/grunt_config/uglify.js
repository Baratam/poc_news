module.exports = {
	uglify: {
		module: {
			files: {
				'dist/module.min.js': 'dist/module.js'
			}
		}
	}
};