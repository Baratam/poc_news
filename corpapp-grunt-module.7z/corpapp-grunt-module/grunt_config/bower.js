module.exports = {
	bower: {
		install: {
			options : {
				copy : false
			}
		}
	}
};